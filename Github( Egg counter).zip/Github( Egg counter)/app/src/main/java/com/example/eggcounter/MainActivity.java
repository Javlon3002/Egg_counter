package com.example.eggcounter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.net.Inet4Address;

public class MainActivity extends AppCompatActivity {

    private int count = 0;
    private EditText edtGet;
    private Button btnNumAdd;
    private Button btnOneAdd;
    private TextView txtShow;
    private Button btnReset;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        edtGet = findViewById(R.id.edtGet);
        btnNumAdd = findViewById(R.id.btnNumAdd);
        btnOneAdd = findViewById(R.id.btnOneAdd);
        txtShow = findViewById(R.id.txtShow);
        btnReset = findViewById(R.id.btnReset);


        txtShow.setText(Integer.toString(count));

        btnNumAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num = Integer.parseInt(edtGet.getText().toString());
                count = count + num;
                txtShow.setText(Integer.toString(count));


            }
        });

        btnOneAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count++;
                txtShow.setText(Integer.toString(count));

            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count = 0;
                txtShow.setText(Integer.toString(count));

            }
        });


    }
}